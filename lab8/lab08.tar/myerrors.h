#pragma once

#include <stdexcept>
#include <iostream> 

// Klasa opisująca wyjątki
namespace myerrors {

	// Klasa wyjątku calc_error
	class calc_error : public std::runtime_error {
	public:

		// Wyjątek calc_error
		calc_error(const std::runtime_error* err, const char* text, const char* file, int line) : std::runtime_error("asd"), 
		parent(err), text(text), file(file), line(line) {
			//std::cout << "z powodu: " << text <<" [w pliku: " << file << " w lini: " << line << "]" << std::endl;
		}

		// pola używane do wypisania wartości z kolejki
		const std::runtime_error* get_parent() { return parent; }
		const std::runtime_error* parent;
		const char* text;
		const char* file;
		int line;

	};

	// Handler dla wyjątków
	static void handler() {
		try { // lippincott function
  	  throw;

		} catch (const calc_error* err) { // łapanie calc_error
			std::cout << "Wyjatek w: ";
			const std::runtime_error* current = err;

			do {
				const calc_error* calc = dynamic_cast<const calc_error*>(current);
				if (calc != nullptr) {
					std::cout << "z powodu: " << calc->text <<" [w pliku: " << calc->file << " w lini: " << calc->line << "]" << std::endl;
					current = calc->parent;
				}
				else {  
					std::cout << current->what() << std::endl;
					//std::cout << "z powodu: " << current->text <<" [w pliku: " << current->file << " w lini: " << current->line << "]" << std::endl;
					current = nullptr;
				}
			} while (current != nullptr);
		}
	}
};
