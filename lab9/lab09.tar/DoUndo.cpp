#include "DoUndo.h"

// Definition of static member ok
bool DoUndo::ok=0;

