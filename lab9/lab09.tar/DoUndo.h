#pragma once

#include <iostream>
#include "DoUndoAction.h"


// Class KeepInt used for saving reference to int
class KeepInt : public DoUndoAction {
public:
	// TODO: implementation of method handling events
	void dodo() {}
	void undoOk() {}
	void undoFail() {i=prev;}

	// Constructor saving reference and value in case it needs to be restored
	KeepInt(int& i) : i(i), prev(i) {}

private:
	// Reference to int i
	int& i;
	// Saved previous value 
	int prev;
};

// Class DoUndo that checks if transaction went fine
class DoUndo {
public:
	// Constructor saving an action
	DoUndo(DoUndoAction* act) : act(act) {act->dodo(); ok=0;}

	// Destructor responsible for telling if everything went alright 
	// If not then it should restore old account value
	~DoUndo() { if (!ok) act->undoFail(); else act->undoOk(); }
	
	// Function that changes value of ok if everything went fine
	static void allok() { ok=1; }

private:
	// Field for saving an action
	DoUndoAction* act;
	// Field used to tell if transaction went fine
	static bool ok;
};