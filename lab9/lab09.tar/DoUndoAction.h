#pragma once

#include <iostream>

// Base class for actions
class DoUndoAction {
public:
  // Virtual methods for handling events description
  virtual void dodo() {
    std::cout << "Entering transaction" << std::endl;
  }    
  virtual void undoOk() {
    std::cout << "Finished transaction" << std::endl;
  }
  virtual void undoFail() {
    std::cout << "Broken transaction" << std::endl;
  }
  
private:
};